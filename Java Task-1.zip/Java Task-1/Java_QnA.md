Java Questions & Answers
1. What is method overloading?
Method overloading means defining multiple methods in the same class with the same name but different parameter lists (type, number, or both). It allows different ways of performing similar operations.
Examples:
int add(int a, int b)
double add(double a, double b)


2. How do you handle divide-by-zero?
In Java, dividing by zero in integers throws an ArithmeticException. For floating-point numbers, it returns Infinity. To handle it safely, use a condition:
if (b != 0) {
    result = a / b;
} else {
    System.out.println("Cannot divide by zero.");
}


3. Difference between == and .equals()?
== checks reference equality (are they the same object in memory).
.equals() checks value/content equality.


4. What are the basic data types in Java?
Java has 8 primitive data types:
byte, short, int, long (integers)
float, double (decimals)
char (single character)
boolean (true/false)

5. How is Scanner used for input?
The Scanner class is used to take input from the user.
import java.util.Scanner;
Scanner scanner = new Scanner(System.in);
int number = scanner.nextInt();   // input integer
String name = scanner.next();     // input string


6. Explain the role of a loop.
Loops are used to repeat a block of code multiple times until a condition is false. They help reduce redundancy and automate repetitive tasks.


7. Difference between while and for loop?
while is used when the number of iterations is not known beforehand.
for is used when the number of iterations is known.


8. What is the JVM?
JVM (Java Virtual Machine) is the engine that runs Java bytecode. It converts the compiled .class file into machine code for the host system, enabling Java programs to run on any platform.


9. How is Java platform-independent?
Java code is compiled into bytecode, which runs on the JVM. Since every platform has its own JVM implementation, the same .class file can run anywhere — "Write Once, Run Anywhere".


10. How do you debug a Java program?
Use print statements to track values.
Use an IDE (like VS Code or IntelliJ) with breakpoints and step-by-step execution.
Observe error messages and stack traces for hints.


